# Next.js with TypeScript example
